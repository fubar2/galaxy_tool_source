###

debug_Ocopy_byteblocks <- function()
    invisible(.Call2("debug_Ocopy_byteblocks", PACKAGE="XVector"))

debug_SharedVector_class <- function()
    invisible(.Call2("debug_SharedVector_class", PACKAGE="XVector"))

debug_SharedRaw_class <- function()
    invisible(.Call2("debug_SharedRaw_class", PACKAGE="XVector"))

debug_SharedInteger_class <- function()
    invisible(.Call2("debug_SharedInteger_class", PACKAGE="XVector"))

debug_SharedDouble_class <- function()
    invisible(.Call2("debug_SharedDouble_class", PACKAGE="XVector"))

debug_XVector_class <- function()
    invisible(.Call2("debug_XVector_class", PACKAGE="XVector"))

