setGeneric("organism", function(object)
           standardGeneric("organism"))

