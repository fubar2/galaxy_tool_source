.test <- function() testPackage("BiocGenerics")
