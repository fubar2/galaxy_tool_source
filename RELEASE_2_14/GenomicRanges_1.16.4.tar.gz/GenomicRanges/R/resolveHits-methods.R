### =========================================================================
### resolveHits methods
### -------------------------------------------------------------------------

resolveHits <- function(query, subject, readValue,
                        type = c("any", "start", "end", "within", "equal"),
                        resolution = c("divide", "uniqueDisjoint"), 
                        ignore.strand, ...)
    .Defunct("summarizeOverlaps")

