##' @export 
print.Hist <- function(x,...){
  summary(x)
}
