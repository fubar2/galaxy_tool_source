## the name ibs is more intuitive for integrated Brier score
## whereas continuous ranked probability score is less well known
##' @export
ibs <- crps
