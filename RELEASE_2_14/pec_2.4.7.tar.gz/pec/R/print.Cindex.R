##' @export
print.Cindex <- function(x,digits=3,what=NULL,times,...){
  summary(x,print=TRUE,...)
}
