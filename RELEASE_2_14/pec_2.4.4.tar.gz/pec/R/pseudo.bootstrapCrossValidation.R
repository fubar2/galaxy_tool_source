pseudo.bootstrapCrossValidation <- function(x,...){
  stop("the function pseudo.bootstrapCrossValidation has to be written")
}
